package com.VideoMaker.Service;

import com.VideoMaker.entity.Voiceover;
import com.VideoMaker.repository.VoiceoverRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class  VoiceoverService  {

    private final VoiceoverRepository voiceoverRepository;

    @Autowired
    public VoiceoverService(VoiceoverRepository voiceoverRepository) {
        this.voiceoverRepository = voiceoverRepository;
    }

    public List<Voiceover> getAllVoiceover() {
        return voiceoverRepository.findAll();
    }

    public Voiceover getVoiceoverById(Long id) {
        return voiceoverRepository.findById(id).orElseThrow(() -> new RuntimeException(("Voiceover not found")));
    }

    public Voiceover createVoiceover(Voiceover voiceover) {
        return voiceoverRepository.save(voiceover);
    }

    public Voiceover updateVoiceover(Long id, Voiceover updatedVoiceover) {
        Voiceover voiceover = getVoiceoverById(id);
        voiceover.setUrl(updatedVoiceover.getUrl());
        voiceover.setVolume(updatedVoiceover.getVolume());
        voiceover.setType(updatedVoiceover.getType());
        voiceover.setDuration(updatedVoiceover.getDuration());
        return voiceoverRepository.save(voiceover);
    }

    public void deleteVoiceover(Long id) {

        voiceoverRepository.deleteById(id);
    }
}



