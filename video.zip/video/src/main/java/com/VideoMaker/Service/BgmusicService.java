package com.VideoMaker.Service;

import com.VideoMaker.entity.Bgmusic;
import com.VideoMaker.repository.BgmusicRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class BgmusicService {

    private final BgmusicRepository bgmusicRepository;

    @Autowired
    public BgmusicService(BgmusicRepository bgmusicRepository) {
        this.bgmusicRepository = bgmusicRepository;
    }

    public List<Bgmusic> getAllBgmusics() {
        return bgmusicRepository.findAll();
    }

    public Bgmusic getBgmusicById(Long id) {
        return bgmusicRepository.findById(id).orElseThrow(() -> new RuntimeException(("Bgmusic not found")));
    }

    public Bgmusic createBgmusic(Bgmusic bgmusic) {
        return bgmusicRepository.save(bgmusic);
    }

    public Bgmusic updateBgmusic(Long id, Bgmusic updatedBgmusic) {
        Bgmusic bgmusic = getBgmusicById(id);
        bgmusic.setUrl(updatedBgmusic.getUrl());
        bgmusic.setVolume(updatedBgmusic.getVolume());
        bgmusic.setType(updatedBgmusic.getType());
        bgmusic.setDuration(updatedBgmusic.getDuration());
        return bgmusicRepository.save(bgmusic);
    }

    public void deleteBgmusic(Long id) {

        bgmusicRepository.deleteById(id);
    }
}

