package com.VideoMaker.Service;

import com.VideoMaker.entity.VideoAudio;
import com.VideoMaker.repository.VideoAudioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

    @Service
    public class VideoAudioService {

        private final VideoAudioRepository videoAudioRepository;

        @Autowired
        public VideoAudioService(VideoAudioRepository videoAudioRepository) {
            this.videoAudioRepository = videoAudioRepository;
        }

        public List<VideoAudio> getAllVideoAudios() {
            return videoAudioRepository.findAll();
        }

        public VideoAudio getVideoAudioById(Long id) {
            return videoAudioRepository.findById(id).orElseThrow(() -> new RuntimeException(("VideoAudio not found")));
        }

        public VideoAudio createVideoAudio(VideoAudio videoAudio) {
            return videoAudioRepository.save(videoAudio);
        }

        public VideoAudio updateVideoAudio(Long id, VideoAudio updatedVideoAudio) {
            VideoAudio videoAudio = getVideoAudioById(id);
            videoAudio.setUrl(updatedVideoAudio.getUrl());
            videoAudio.setVolume(updatedVideoAudio.getVolume());
            videoAudio.setType(updatedVideoAudio.getType());
            videoAudio.setDuration(updatedVideoAudio.getDuration());
            return videoAudioRepository.save(videoAudio);
        }

        public void deleteVideoAudio(Long id) {
            videoAudioRepository.deleteById(id);
        }
    }
