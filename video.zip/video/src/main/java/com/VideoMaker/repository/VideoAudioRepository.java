package com.VideoMaker.repository;

import com.VideoMaker.entity.VideoAudio;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface VideoAudioRepository extends JpaRepository<VideoAudio, Long> {

}
