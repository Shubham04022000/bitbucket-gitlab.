package com.VideoMaker.controller;

import com.VideoMaker.Service.BgmusicService;
import com.VideoMaker.entity.Bgmusic;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@RequestMapping("/Bgmusic")
public class BgmusicController {

    private final BgmusicService bgmusicService;

    @Autowired
    public BgmusicController(BgmusicService bgmusicService) {
        this.bgmusicService = bgmusicService;
    }

    @GetMapping
    public ResponseEntity<List<Bgmusic>> getAllBgmusics() {
        List<Bgmusic> bgmusics = bgmusicService.getAllBgmusics();
        return ResponseEntity.ok(bgmusics);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Bgmusic> getBgmusicById(@PathVariable Long id) {
        Bgmusic bgmusic = bgmusicService.getBgmusicById(id);
        return ResponseEntity.ok(bgmusic);
    }
    // http://localhost:8080/Bgmusic
    @PostMapping
    public ResponseEntity<Bgmusic> createBgmusic(@RequestBody Bgmusic bgmusic) {
        Bgmusic createdBgmusic = bgmusicService.createBgmusic(bgmusic);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdBgmusic);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Bgmusic> updateBgmusic(@PathVariable Long id, @RequestBody Bgmusic bgmusic) {
        Bgmusic updatedBgmusic = bgmusicService.updateBgmusic(id, bgmusic);
        return ResponseEntity.ok(updatedBgmusic);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBgmusic(@PathVariable Long id) {
        bgmusicService.deleteBgmusic(id);
        return ResponseEntity.noContent().build();
    }
}
