package com.VideoMaker.controller;

import com.VideoMaker.Service.VideoAudioService;
import com.VideoMaker.entity.VideoAudio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/videoaudio")
public class VideoAudioController {

    private final VideoAudioService videoAudioService;

    @Autowired
    public VideoAudioController(VideoAudioService videoAudioService) {
        this.videoAudioService = videoAudioService;
    }

    @GetMapping
    public ResponseEntity<List<VideoAudio>> getAllVideoAudios() {
        List<VideoAudio> videoAudios = videoAudioService.getAllVideoAudios();
        return ResponseEntity.ok(videoAudios);
    }

    @GetMapping("/{id}")
    public ResponseEntity<VideoAudio> getVideoAudioById(@PathVariable Long id) {
        VideoAudio videoAudio = videoAudioService.getVideoAudioById(id);
        return ResponseEntity.ok(videoAudio);
    }
    // http://localhost:8080/videoaudio
    @PostMapping
    public ResponseEntity<VideoAudio> createVideoAudio(@RequestBody VideoAudio videoAudio) {
        VideoAudio createdVideoAudio = videoAudioService.createVideoAudio(videoAudio);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdVideoAudio);
    }

    @PutMapping("/{id}")
    public ResponseEntity<VideoAudio> updateVideoAudio(@PathVariable Long id, @RequestBody VideoAudio videoAudio) {
        VideoAudio updatedVideoAudio = videoAudioService.updateVideoAudio(id, videoAudio);
        return ResponseEntity.ok(updatedVideoAudio);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteVideoAudio(@PathVariable Long id) {
        videoAudioService.deleteVideoAudio(id);
        return ResponseEntity.noContent().build();
    }
}

