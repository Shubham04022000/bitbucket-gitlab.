package com.VideoMaker.controller;

import com.VideoMaker.Service.VoiceoverService;
import com.VideoMaker.entity.Voiceover;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/Voiceover")
public class VoiceoverController {

    private final VoiceoverService voiceoverService;

    @Autowired
    public VoiceoverController(VoiceoverService voiceoverService) {
        this.voiceoverService = voiceoverService;
    }

    @GetMapping
    public ResponseEntity<List<Voiceover>> getAllVoiceover() {
        List<Voiceover> voiceover = voiceoverService.getAllVoiceover();
        return ResponseEntity.ok(voiceover);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Voiceover> getVoiceoverById(@PathVariable Long id) {
        Voiceover voiceover = voiceoverService.getVoiceoverById(id);
        return ResponseEntity.ok(voiceover);
    }
        // http://localhost:8080/Voiceover
    @PostMapping
    public ResponseEntity<Voiceover> createVoiceover(@RequestBody Voiceover voiceover) {
        Voiceover createdVoiceover = voiceoverService.createVoiceover(voiceover);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdVoiceover);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Voiceover> updateVoiceover(@PathVariable Long id, @RequestBody Voiceover voiceover) {
        Voiceover updatedVoiceover = voiceoverService.updateVoiceover(id, voiceover);
        return ResponseEntity.ok(updatedVoiceover);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteVoiceover(@PathVariable Long id) {
        voiceoverService.deleteVoiceover(id);
        return ResponseEntity.noContent().build();
    }
}
